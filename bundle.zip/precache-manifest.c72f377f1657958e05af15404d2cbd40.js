self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5244fd01cd29fc60ab387bd390a66774",
    "url": "/index.html"
  },
  {
    "revision": "0df29d15af1211cb4c91",
    "url": "/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "bf93645d5b9e8d0007f5",
    "url": "/static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "0df29d15af1211cb4c91",
    "url": "/static/js/2.9d5e692c.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.9d5e692c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "bf93645d5b9e8d0007f5",
    "url": "/static/js/main.278f3db6.chunk.js"
  },
  {
    "revision": "55eef6f2ea716c26d9b1",
    "url": "/static/js/runtime-main.69b99518.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);